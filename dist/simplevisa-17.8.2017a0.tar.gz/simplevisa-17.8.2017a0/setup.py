from setuptools import setup

setup(
	name='simplevisa',    	
	version='17.08.2017a',                         
	scripts=['simplevisa']                  
)